chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://")) {
    console.error("Cannot run extension on browser internal pages.");
    return;
  }

  // PDF Redirect: Chrome prevents content scripts on native PDF viewers
  if (tab.url.toLowerCase().endsWith('.pdf') || tab.url.includes('pdf')) {
    const dashboardUrl = `http://localhost:3000/dashboard?url=${encodeURIComponent(tab.url)}`;
    chrome.tabs.create({ url: dashboardUrl });
    return;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (err) {
    console.error("Failed to inject FocusReader:", err);
  }
});
