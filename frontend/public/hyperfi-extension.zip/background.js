/**
 * Hyperfi Reader — Background Service Worker (Manifest V3)
 * Orchestrates offscreen document for continuous voice command capture and relays commands to active tabs.
 */

let creatingOffscreen = false;

async function setupOffscreenDocument() {
  if (await chrome.offscreen.hasDocument()) return;
  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }
  creatingOffscreen = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['AUDIO_CAPTURE', 'USER_MEDIA'],
    justification: 'Continuous hands-free voice commands and wake-word recognition for ADHD Bionic Reader'
  });
  await creatingOffscreen;
  creatingOffscreen = false;
}

async function closeOffscreenDocument() {
  if (!(await chrome.offscreen.hasDocument())) return;
  await chrome.offscreen.closeDocument();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ENABLE_VOICE_CONTROLLER') {
    setupOffscreenDocument()
      .then(() => sendResponse({ status: 'enabled' }))
      .catch((err) => sendResponse({ status: 'error', error: err.message }));
    return true; // Keep channel open for async response
  } else if (message.action === 'DISABLE_VOICE_CONTROLLER') {
    closeOffscreenDocument()
      .then(() => sendResponse({ status: 'disabled' }))
      .catch((err) => sendResponse({ status: 'error', error: err.message }));
    return true;
  } else if (message.action === 'VOICE_COMMAND_DETECTED') {
    // Relay command from offscreen.js to active tab's content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'VOICE_COMMAND',
          command: message.command,
          transcript: message.transcript
        }).catch(() => {/* tab might not have content script ready */});
      }
    });
  }
});
